#include<stdio.h>
void main(){
    int num1,num2,num3,num4,num5;
    printf("Enter five number: ");
    scanf("%d%d%d%d%d",&num1,&num2,&num3,&num4,&num5);
    if(num1%2==0){
        printf("\n %d is an even number",num1);
    }
    else{
        printf("\n %d is an odd number",num1);
    }

    if(num2%2==0){
        printf("\n %d is an even number",num2);
    }
    else{
        printf("\n %d is an odd number",num2);
    }

    if(num3%2==0){
        printf("\n %d is an even number",num3);
    }
    else{
        printf("\n %d is an odd number",num3);
    }

    if(num4%2==0){
        printf("\n %d is an even number",num4);
    }
    else{
        printf("\n %d is an odd number",num4);
    }

    if(num5%2==0){
        printf("\n %d is an even number",num5);
    }
    else{
        printf("\n %d is an odd number",num5);
    }
}

