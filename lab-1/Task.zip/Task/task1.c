#include<stdio.h>
void main(){
    int num;
    printf("Enter a number:");
    scanf("%d",&num);
    printf("Your inserted number is: %d",num);
}
